﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace farmer
{
    public partial class simple_dairy : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnadd_Click(object sender, EventArgs e)
        {
            int res = int.Parse(TextBox1.Text) + int.Parse(TextBox2.Text);
            txtres.Text = res.ToString();
        }

        protected void btnsub_Click(object sender, EventArgs e)
        {
            int res = int.Parse(TextBox1.Text) -  int.Parse(TextBox2.Text);
            txtres.Text = res.ToString();
        }

        protected void btnmul_Click(object sender, EventArgs e)
        {
            int res = int.Parse(TextBox1.Text) * int.Parse(TextBox2.Text);
            txtres.Text = res.ToString();
        }

        protected void btndiv_Click(object sender, EventArgs e)
        {
            double res = double.Parse(TextBox1.Text) / double.Parse(TextBox2.Text);
            txtres.Text = res.ToString();
        }

        protected void btncna_Click(object sender, EventArgs e)
        {
            ListBox1.Items.Add(TextBox3.Text);
        }

        protected void btnremove_Click(object sender, EventArgs e)
        {
            ListBox1.Items.Remove(ListBox1.SelectedItem);
        }
    }
}