﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;

namespace farmer
{
    public partial class create_account : System.Web.UI.Page
    {
       



        protected void btnCreate_Click(object sender, EventArgs e)
        {
            
        }
    }
}