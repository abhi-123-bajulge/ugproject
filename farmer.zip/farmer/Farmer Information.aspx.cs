﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;

namespace farmer
{
    public partial class Farmer_Information : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            OleDbConnection con = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source=C:\Users\Abhi\Documents\database file\info.accdb");
            con.Open();
            OleDbCommand cmd = new OleDbCommand("insert into Farmer Information values('" + TextBox1.Text + "','" + TextBox2.Text + "'," + TextBox3.Text + "," + TextBox4.Text + "," + TextBox5.Text + ",)",con);
           
            con.Close();
          
           
        }
    }
}