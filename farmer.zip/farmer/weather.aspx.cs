﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace farmer
{
    public partial class whether : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            double txt1 = Convert.ToDouble(TextBox1.Text);

            double product = (txt1 * 1.8) + 32;



            TextBox2.Text = product.ToString();
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            double txt1 = Convert.ToDouble(TextBox1.Text);

            double product = (txt1 * +273.15);
            TextBox3.Text = product.ToString();
        }
    }
}