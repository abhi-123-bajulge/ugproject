﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Data.OleDb;
using System.Data;

namespace farmer
{
    public partial class login : System.Web.UI.Page
    {

        protected void Page_Load(object sender, EventArgs e)
        {

            Label1.Visible = false;

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {


            OleDbConnection conn = new OleDbConnection(@"Provider=Microsoft.ACE.OLEDB.12.0;Data Source= C:\Users\L6_24\Documents\ab\data.accdb");
            conn.Open();
            OleDbCommand cmd = new OleDbCommand(" insert into Table1 values('" + uname.Text + "'," + pass.Text + ")", conn);
            int R = cmd.ExecuteNonQuery();
            conn.Close();
            if (R > 0)
            {
                Label1.Visible = true;
            }

        }
    }
}